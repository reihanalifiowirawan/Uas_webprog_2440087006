@extends('template')

@section('title', 'Login')

@section('content')

<div>
    <div class=" shadow-lg justify-content-center d-flex flex-column align-items-center" style="width: 50vw">
        <div class="display-4 m-2">{{__('auth.Login')}}</div>
        <form class="bg-light p-5" action="/login" method="POST" style="width: 50vw">
            @csrf
            <div class="mb-3">
                <label for="email" class="form-label">{{__('auth.Email')}}: </label>
                <input type="text" class="form-control" id="email" name="email" aria-describedby="emailHelp"
                    value={{ Cookie::get('email_cookie') !=null ?
                    Cookie::get('email_cookie') : old('email') }}>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password: </label>
                <input type="password" class="form-control" id="password" name="password"
                    value={{ Cookie::get('password_cookie') !=null ?
                    Cookie::get('password_cookie') : '' }}>
            </div>
            <button type="submit" class="btn btn-warning" value="Login">{{__('auth.Login')}}</button>

            <div class="mt-5"><a href="/register">{{__('auth.warn')}}</a></div>
            <a href="/login/{{__('auth.refer')}}" class="btn btn-warning">Language Localization</a>
        </form>
    </div>
</div>

@endsection
