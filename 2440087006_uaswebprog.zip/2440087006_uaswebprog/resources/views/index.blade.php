@extends('template')

@section('title', 'Index')

@section('content')
<style>
    .circle{
        height: 500px;
        width: 500px;
        border-radius: 50%;
        background: rgb(251, 249, 249);
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto;
        border: 10px solid #c6e006;
        outline-style: solid;
        outline-color: #d51103;
    }
    .center{
        font-size: 35px;
        text-align: center;
    }
</style>
<div class="circle">
    <h1 class="center" style="color : #050505">
        Find your items here!
    </h1>
</div>

@endsection
