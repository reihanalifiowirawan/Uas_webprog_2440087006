<?php $__env->startSection('title', 'Cart'); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column align-items-center justify-content-center">
        <h3 class=""><u>Cart</u></h3>
        <?php if(count($carts) == 0): ?>
            <div class="mb-5">The cart is empty!</div>
        <?php endif; ?>
        <div style="margin: 2rem" class="align-self-center"></div>
        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a class="col" style="text-decoration: none; width: 64rem;" href="/product/<?php echo e($cart->product->id); ?>">
                <div class="card mb-3" style="width: 64rem;">
                    <div class="row g-0 d-flex flex-row justify-content-center">
                        <div class="col text-center">
                            <img src="assets/vege1.png" class="img-fluid rounded-start" alt=<?php echo e($cart->product->name); ?>

                                style="width: 12rem; height:12rem">
                        </div>
                        <div class="col">
                            <div class="card-body text-center mt-5">
                                <h5 class="card-title" style="color: #747474"><?php echo e($cart->product->name); ?></h5>
                                <p class="card-text" style="color: #747474">Total Price: Rp. <?php echo e(number_format($cart->subTotal, 0, ',', '.').',-'); ?></p>
                                <a href="<?php echo e(url('deletecart', $cart->id)); ?>">Delete</a>
                            </div>
                        </div>
                    </div>
                </div>
            </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(count($carts) != 0): ?>
        <form action="<?php echo e(route('purchase')); ?>" class="d-flex flex-row align-items-center justify-content-center mt-5"
            method="POST">
            <?php echo csrf_field(); ?>
            <div class="me-5 display-6 font-weight-bold">TOTAL: Rp. <?php echo e(number_format($totalPrice, 0, ',', '.').',-'); ?></div>
            <button type="submit" class="btn btn-info" value="Purchase">Check Out</button>
        </form>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\deond\Documents\Semester 5\Web programming\UAS Webprog1\resources\views/cart.blade.php ENDPATH**/ ?>