<?php $__env->startSection('title', $product->name.' details'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column">
    <div class="d-flex flex-row g-4 p-5 justify-content-center">
        <div class="rounded-5">
            <h5 class="ms-5 font-weight-bold"><u><?php echo e($product->name); ?></u></h5>
            <img src="/assets/part1.png" class=" img-fluid rounded-start"
                style="width: 15rem; max-height: 15rem;">
        </div>
        <div class="rounded-end p-5">
            <div class="card-body">
                <br>
                <div class="d-flex flex-row mb-5 font-weight-bold">
                    <div class="me-5 font-weight-bold">Price: </div>
                    <div class="font-weight-bold"><?php echo e('Rp. '.number_format($product->price, 0, ',', '.').',-'); ?></div>
                </div>
                <div style="width: 54rem" class="d-flex flex-row mb-5">
                    <div><?php echo e($product->description); ?></div>
                </div>
                <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->role != null): ?>
                <form action="/product/<?php echo e($product->id); ?>" class="d-flex flex-column" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-info" value="Purchase">Buy</button>
                </form>
                <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\deond\Documents\Semester 5\Web programming\UAS Webprog1\resources\views/product_detail.blade.php ENDPATH**/ ?>