<?php $__env->startSection('title',  $data->name.' Role'); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex flex-column align-items-center justify-content-center">
        <div style="margin: 2rem" class="align-self-center"></div>
        <div class="col" style="text-decoration: none; width: 64rem;">
            <div class="card mb-3" style="width: 64rem;">
                <div class="row g-0 d-flex flex-row justify-content-center">
                    <div class="col">
                        <div class="card-body mt-4">
                            <form class="p-5" action="/maintenance/<?php echo e($data->id); ?>" method="POST" enctype="multipart/form-data" style="width: 50vw">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="role" class="form-label" value="">Role</label>
                                    <select id="role" class="form-control selector" name="role">
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($role); ?>"
                                                <?php if($role == $data->role): ?> selected="selected" <?php endif; ?>><?php echo e($role); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-warning" value="Register">Save</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\deond\Documents\Semester 5\Web programming\UAS Webprog1 - Copy\resources\views/accountdetail.blade.php ENDPATH**/ ?>