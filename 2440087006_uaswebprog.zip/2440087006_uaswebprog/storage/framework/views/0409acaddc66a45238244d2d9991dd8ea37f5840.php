<?php $__env->startSection('title', 'Acount Maintanance'); ?>

<?php $__env->startSection('content'); ?>
<style>
    table, th, td {
      border: 1px solid black;
      border-collapse: collapse;
    }
    table.center {
      margin-left: auto;
      margin-right: auto;
    }
    </style>
<table class="text-center align-middle mx-auto">
    <tr>
      <th><u>Account</u></th>
      <th><u>Action</u></th>
    </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user->first_name . ' ' .$user->last_name . ' - ' . $user->role); ?></td>
        <td><a href="/maintenance/<?php echo e($user->id); ?>">Update Role</a> <a href="/deleteacc/<?php echo e($user->id); ?>"> Delete</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\deond\Documents\Semester 5\Web programming\UAS Webprog1\resources\views/accountmanage.blade.php ENDPATH**/ ?>