<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>

<div>
    <div class=" shadow-lg justify-content-center d-flex flex-column align-items-center" style="width: 50vw">
        <div class="display-4 m-2"><?php echo e(__('auth.Login')); ?></div>
        <form class="bg-light p-5" action="/login" method="POST" style="width: 50vw">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="email" class="form-label"><?php echo e(__('auth.Email')); ?>: </label>
                <input type="text" class="form-control" id="email" name="email" aria-describedby="emailHelp"
                    value=<?php echo e(Cookie::get('email_cookie') !=null ?
                    Cookie::get('email_cookie') : old('email')); ?>>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">Password: </label>
                <input type="password" class="form-control" id="password" name="password"
                    value=<?php echo e(Cookie::get('password_cookie') !=null ?
                    Cookie::get('password_cookie') : ''); ?>>
            </div>
            <button type="submit" class="btn btn-warning" value="Login"><?php echo e(__('auth.Login')); ?></button>

            <div class="mt-5"><a href="/register"><?php echo e(__('auth.warn')); ?></a></div>
            <a href="/login/<?php echo e(__('auth.refer')); ?>" class="btn btn-warning">Language Localization</a>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\deond\Documents\Semester 5\Web programming\UAS Webprog1 - Copy\resources\views/login.blade.php ENDPATH**/ ?>