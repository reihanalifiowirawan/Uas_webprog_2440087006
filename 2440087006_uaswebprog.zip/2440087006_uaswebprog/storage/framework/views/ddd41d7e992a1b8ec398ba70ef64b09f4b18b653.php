<?php $__env->startSection('title', 'Check Out'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .circle {
            height: 500px;
            width: 500px;
            border-radius: 50%;
            background: rgb(251, 250, 250);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
            border: 10px solid #ffeb14;
            outline-style: solid;
            outline-color: #ee1905;
        }

        .center h2{
            font-size: 35px;
            text-align: center;
        }
        .center h4{
            font-size: 20px;
        }
    </style>
    <div class="circle">
        <div class="col text-center">
            <h2 class="center" style="color:#050505">
                Thanks for checkouting!
            </h2>
            <br>
            <h4 class="center" style="color : #050505">
                We will contact you 1x24 hours
            </h4>
            <a href="/home" class="center">
                Back to home
            </a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\deond\Documents\Semester 5\Web programming\UAS Webprog1 - Copy\resources\views/checkout.blade.php ENDPATH**/ ?>