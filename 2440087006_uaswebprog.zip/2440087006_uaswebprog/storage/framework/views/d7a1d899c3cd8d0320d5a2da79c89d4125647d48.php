<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row row-cols-1 row-cols-md-5 g-4 p-5">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col" style="text-decoration: none">
                <div class="card h-100" style="width: 12rem; overflow: hidden">
                    <img src="assets/part1.png" class="card-img-top" alt=<?php echo e($product->name); ?>

                        style="width: 12rem; height:12rem">
                    <div class="card-body text-center">
                        <p class="card-text" style="color: black"><?php echo e($product->name); ?></p>
                        <a class="card-text" href="/product/<?php echo e($product->id); ?>">Detail</a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
    <div style="" class="align-self-center text-center">
        <?php echo e($products->links()); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\deond\Documents\Semester 5\Web programming\UAS Webprog1\resources\views/welcome.blade.php ENDPATH**/ ?>