<?php $__env->startSection('title', 'Check Out'); ?>

<?php $__env->startSection('content'); ?>
    <style>
        .circle {
            height: 500px;
            width: 500px;
            border-radius: 50%;
            background: rgb(82, 82, 82);
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto;
            border: 10px solid #52fbf8;
            outline-style: solid;
            outline-color: #52fbf8;
        }

        .center h2{
            font-size: 35px;
            text-align: center;
        }
        .center h4{
            font-size: 20px;
        }
    </style>
    <div class="circle">
        <div class="col text-center">
            <h2 class="center" style="color:#fff">
                Check Out Success!
            </h2>
            <br>
            <h4 class="center" style="color : #fff">
                We will contact you within 24 hours.
            </h4>
            <a href="/home" class="center">
                Click here to go back
            </a>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\deond\Documents\Semester 5\Web programming\UAS Webprog1\resources\views/checkout.blade.php ENDPATH**/ ?>